var borrador = { 
    position: [0, 0],
    active:false,
    radius:50,
    delete:false,
    fillStyle: "white",
    strokeStyle: "#c3c3c3",
};

borrador.changeMode = function(){
    if(this.delete){
        this.delete = false;
        $(".eliminar").attr("src","images/eliminar.png");
    }
    else{
        this.delete = true;
        $(".eliminar").attr("src","images/segmento.png");
    }
}

borrador.isBetween = function(aX,aY,bX,bY,cX,cY){
    if((aX > cX && cX > bX)||(aX < cX && cX < bX)||(aX == cX && cX == bX))
        if((aY > cY && cY > bY)||(aY < cY && cY < bY)||(aY == cY && cY == bY))
            return true;
    return false;
}

borrador.isBetweenAngles = function(s,e,a){
    if(s > e ){
        if(s < a || a < e)
            return true;
    }
    if(s < e && a > s && a < e)
        return true;
    return false;

}

borrador.intersectToRect = function(x1,x2,y1,y2,xC,yC,r,i){  //devuelve las rotaciones sobre la linea original
    x1 = x1 -xC;
    x2 = x2 -xC;
    y1 = y1 -yC;
    y2 = y2 -yC;
    var abc = findGeneralLineEquation(x1,x2,y1,y2);
    var a=0,b=0,c=0;
    a = abc[0]; b = abc[1]; c = abc[2]; 
    //c = c - (a*xC) - (b*yC);
    var iX1=0, iX2=0, iY1=0, iY2=0; //puntos de interseccion
    var exp = 0;
    exp = Math.pow(r,2) * (Math.pow(a,2) + Math.pow(b,2)) - Math.pow(c,2); 
    if (exp <0 ) {return;} // no hubo interseccion 

    exp = Math.sqrt(exp);
    iX1 = ((a * c )+ b * exp)/(Math.pow(a,2) + Math.pow(b,2));
    iX2 = ((a * c )- b * exp)/(Math.pow(a,2) + Math.pow(b,2));
    iY1 = ((b * c )- a * exp)/(Math.pow(a,2) + Math.pow(b,2));
    iY2 = ((b * c )+ a * exp)/(Math.pow(a,2) + Math.pow(b,2));

     iX1 = -iX1 +xC;
     iX2 = -iX2 +xC;
     iY1 = -iY1 +yC;
     iY2 = -iY2 +yC;
    //codigo para dibujar intersecciones
    // var p1 = [iX1,iY1];
    // var p2 = [iX2,iY2];

    // p1 = point.rotate(rectas[i].getRotation(),p1[0],p1[1],0,0);
    // p2 = point.rotate(rectas[i].getRotation(),p2[0],p2[1],0,0);
    // console.log(rectas[i].getRotation());
    // var t = rectas[i].getTranslation();
    // p1 = point.translate(t[0],t[1],p1[0], p1[1]);
    // p2 = point.translate(t[0],t[1],p2[0], p2[1]);

    // this.intersectToRections[0] = p1[0]; 
    // this.intersectToRections[1] = p1[1]; 
    // this.intersectToRections[2] = p2[0]; 
    // this.intersectToRections[3] = p2[1]; 


    var btw1 = false, btw2 = false;
    a = rectas[i].getStartPoint();
    b = rectas[i].getEndPoint();
    //console.log("ax="+a[0] + "  ay="+a[1]+"  bx="+b[0]+"  by="+b[1] + "  cx="+iX1+"  cy="+iY1 );

    btw1 = borrador.isBetween(a[0],a[1],b[0],b[1],iX1,iY1);
    btw2 = borrador.isBetween(a[0],a[1],b[0],b[1],iX2,iY2);

    if(btw1 ==true && btw2 ==true){
        var newLine = jQuery.extend(true, {}, rectas[i]);
        if (distance(a[0],a[1],iX1,iY1) < distance(b[0],b[1],iX1,iY1)) { //si el borrador esta dentro de la linea
            if(this.delete){rectas.splice(i,1);  return;}
            rectas[i].setStartPoint(a[0],a[1]);
            rectas[i].setEndPoint(iX1,iY1);

            newLine.setStartPoint(iX2,iY2);
            newLine.setEndPoint(b[0],b[1]);
            rectas.push(newLine);
            return;
        };
    }
    else if(btw1 ==false && btw2 ==false){
        //console.log("ninguno");
        if (iX1 < a[0] && iX2 < a[0] || iX1 < b[0] && iX2 < b[0] ||
            iX1 > a[0] && iX2 > a[0] || iX1 > b[0] && iX2 > b[0] ||
            iY1 > a[1] && iY2 > a[1] || iY1 > b[1] && iY2 > b[1] ||
            iY1 < a[1] && iY2 < a[1] || iY1 < b[1] && iY2 < b[1] ) //si la linea completamente fuera
                return;
        if(iX1 < a[0] && iX2 > b[0] || iX1 < b[0] && iX2 > a[0]  ||
           iX2 < a[0] && iX1 > b[0] || iX2 < b[0] && iX1 > a[0]  ||
           iY1 < a[1] && iY2 > b[1] || iY1 < b[1] && iY2 > a[1]  ||
           iY2 < a[1] && iY1 > b[1] || iY2 < b[1] && iY1 > a[1]  ){ //si la linea esta completamente dentro
                rectas.splice(i,1); 
                return;
            } 
    }else if(btw1 ==true && btw2 ==false){ //si 1 es el punto dentro de la interseccion
        if( distance(a[0],a[1],iX2,iY2) < distance(b[0],b[1],iX2,iY2)){ //el punto mas cercano a 2 se borra
            if(this.delete){rectas.splice(i,1);  return;}
            rectas[i].setStartPoint(iX1,iY1);
            rectas[i].setEndPoint(b[0],b[1]); 
            return;
        }else{
            if(this.delete){rectas.splice(i,1);  return;}
            rectas[i].setStartPoint(iX1,iY1);
            rectas[i].setEndPoint(a[0],a[1]); 
            return;
        }
    }else{ // bt2 es true y btw1 es false
        if(distance(a[0],a[1],iX1,iY1) < distance(b[0],b[1],iX1,iY1)){ //el punto mas cercano a 1 se borra
            if(this.delete){rectas.splice(i,1);  return;}
            rectas[i].setStartPoint(iX2,iY2);
            rectas[i].setEndPoint(b[0],b[1]); 
            return;
        }else{
            if(this.delete){rectas.splice(i,1);  return;}
            rectas[i].setStartPoint(iX2,iY2);
            rectas[i].setEndPoint(a[0],a[1]); 
            return;
        }
    }
    //console.log(btw1);
    //console.log(btw2);
};

borrador.intersectToArc = function(x,y,i){  //http://paulbourke.net/geometry/circlesphere/
    var x0,y0,r0,x1,y1,r1, d;
    x0 = this.position[0];
    y0 = this.position[1];
    r0 = this.radius;
    
    x1 = arcos[i].getXCentro();
    y1 = arcos[i].getYCentro();
    r1 = arcos[i].getRadius();

    d = distance(x0,y0,x1,y1);
    if(d > (r0 +r1))  //los circulos estan separados
        return;
    if(d < Math.abs(r0 -r1)){ //un circulo esta contenido dentro del otro
        if(r1<r0) //el arco esta contenido en el borrador
            arcos.splice(i,1); 
        return;
    } 
        

    //encontrar ecuacion de la recta que se intersecta con el primer circulo igual que el segundo
    // var a,b,c;
    // a = 2*(x2-x1);
    // b = 2*(y2-y1);
    // c = (r1*r1) - (x1*x1) - (y1*y1) - (r2*r2) + (x2*x2) + (y2*y2);

    var a = ((r0*r0) - (r1*r1) + (d*d)) / (2*d);

    var h = Math.sqrt(r0*r0 - a*a);

    var x2,y2; //las coordenadas del punto intermedio entre p0 y p1

    x2= x0 + a* (x1-x0) /d;
    y2= y0 + a* (y1-y0) /d;

    var x3, y3, x4, y4; //los dos puntos de interseccion

    x3 = x2 + h * (y1-y0) /d;
    y3 = y2 - h * (x1-x0) /d;
    x4 = x2 - h * (y1-y0) /d;
    y4 = y2 + h * (x1-x0) /d;

    var angleI1 = Math.atan((y3 - arcos[i].getYCentro()) / (x3 - arcos[i].getXCentro())); //angulos de interseccion
    if(arcos[i].getXCentro()- x3 > 0 && y3 -arcos[i].getYCentro() > 0){
        angleI1 = angleI1 + Math.PI;
    };
    if(arcos[i].getXCentro()- x3 > 0 && y3 -arcos[i].getYCentro() < 0){
        angleI1 = angleI1 + Math.PI;
    };
    if(angleI1 <0 )
        angleI1+=2*Math.PI;

    var angleI2 = Math.atan((y4 - arcos[i].getYCentro()) / (x4 - arcos[i].getXCentro()));
    if(arcos[i].getXCentro()- x4 > 0 && y4 -arcos[i].getYCentro() > 0){
        angleI2 = angleI2 + Math.PI;
    };
    if(arcos[i].getXCentro()- x4 > 0 && y4 -arcos[i].getYCentro() < 0){
        angleI2 = angleI2 + Math.PI;
    };
    if(angleI2 <0 )
        angleI2+=2*Math.PI;

    var s,e,i1,i2; //variable auxiliares para la comparacion
    s = arcos[i].getStartAngle();
    e = arcos[i].getEndAngle();
    i1 = angleI1;
    i2 = angleI2;


    var btw1 = false, btw2 = false, btw3 = false, btw4 = false;
    btw1 = borrador.isBetweenAngles(arcos[i].getStartAngle(), arcos[i].getEndAngle(),angleI1);
    btw2 = borrador.isBetweenAngles(arcos[i].getStartAngle(), arcos[i].getEndAngle(),angleI2);
    btw3 = borrador.isBetweenAngles(angleI1,angleI2,arcos[i].getStartAngle());
    btw4 = borrador.isBetweenAngles(angleI1,angleI2,arcos[i].getEndAngle());
    if(btw1 && btw2){ //hay dos intersecciones, el borrador esta dentro del arco
        if(this.delete){arcos.splice(i,1);  return;}
        var newArc= jQuery.extend(true, {}, arcos[i]);
        //console.log("i1:"+i1+" i2:"+i2);
        arcos[i].setEndAngle(closestAngle(i1,i2,s));
        newArc.setStartAngle(closestAngle(i1,i2,e));
        //console.log("closest:" + closestAngle(i1,i2,e))
        arcos.push(newArc);
        return;
    }
    if(btw1 && !btw2){ //si i1 esta contenido e i2 no
        if(this.delete){arcos.splice(i,1);  return;}
        if(closestAngle(e,s,i2)==e){
            arcos[i].setEndAngle(i1);
        }else{
            arcos[i].setStartAngle(i1);
        }
    }
    if(btw2 && !btw1){ //si i2 esta contenido e i1 no
        if(this.delete){arcos.splice(i,1);  return;}
        if(closestAngle(e,s,i1)==e){
            arcos[i].setEndAngle(i2);
        }else{
            arcos[i].setStartAngle(i2);
        }
    }  

    if(!btw3 && !btw4){
        arcos.splice(i,1);
    }


    // if((arcos[i].getStartAngle() < (arcos[i].getEndAngle()){
    //     if((arcos[i].getStartAngle() < angleI1 && arcos[i].getEndAngle() > angleI2)||
    //        (arcos[i].getStartAngle() < angleI2 && arcos[i].getEndAngle() > angleI1)){

    //     }   
    // }

    // this.intersectToRections[0] = x3; 
    // this.intersectToRections[1] = y3; 
    // this.intersectToRections[2] = x4; 
    // this.intersectToRections[3] = y4; 

    //console.log("a1: "+angleI1 +"  a2: "+ angleI2);
}

borrador.checkRects = function(x,y){
    for(i = 0 ; i< rectas.length ; i++){
        startPoint = rectas[i].getStartPoint(); 
        endPoint = rectas[i].getEndPoint();
        eraserPos = borrador.getPosToLine(rectas[i],x, y);
        //console.log("ePos = "+ eraserPos[0]+","+eraserPos[1]);
        borrador.intersectToRect(startPoint[0], endPoint[0],startPoint[1], endPoint[1],
                                    eraserPos[0],eraserPos[1],borrador.radius, i);
    }
}

borrador.checkArcs = function(x,y){
    for(i = 0 ; i< arcos.length ; i++){
        borrador.intersectToArc(x,y,i);
    }
}

borrador.checkPoints = function(x,y){
    for(i = 0 ; i< puntos.length ; i++){
        if(distance(puntos[i].x,puntos[i].y,x,y) < this.radius){  //si el punto esta dentro del borrador
            puntos.splice(i,1);
        }
             
    }
}

borrador.getRadius = function(){
    return this.radius;
}

borrador.setPosition = function(x,y){
this.position[0] = x;
this.position[1] = y;
}


borrador.increaseSize = function(){
    if(this.radius<99)
        this.radius = this.radius + 1;
    document.getElementById("tamano").innerHTML = this.radius;
    redraw();
}

borrador.decreaseSize = function(){
    if(this.radius>1)
        this.radius = this.radius - 1;
    document.getElementById("tamano").innerHTML = this.radius;
    redraw();
}

borrador.getPosToLine = function(recta,x,y){
    var t = recta.getTranslation();
    var p = point.translate(x,y,-t[0],-t[1]);
        p = point.rotate(-recta.getRotation(), p[0], p[1],0,0);
    return p;
}

borrador.erase = function(){
    var i=0;
    $('#myCanvas').mousedown(function(e){
        if (i==0 && borrador.active){
            borrador.checkRects(e.pageX-60,e.pageY);
            borrador.checkPoints(e.pageX-60,e.pageY);
            borrador.checkArcs(e.pageX-60,e.pageY);
            i++;
        }
    });

    $('#myCanvas').mousemove(function(e){
        borrador.setPosition(e.pageX-60, e.pageY);
        if(i==1 && borrador.active){
            borrador.checkRects(e.pageX-60,e.pageY);
            borrador.checkArcs(e.pageX-60,e.pageY);
            borrador.checkPoints(e.pageX-60,e.pageY);
        }
    });

    $('#myCanvas').mouseup(function(e){
        if(i==1 && borrador.active){
            i=0;
        }
    });
}



borrador.activateDeactivate = function(){
    if(this.active){
        activeTool = false;
        this.active = false;
        canvas.style.cursor = "auto";
    }else{
        activeTool = true;
        this.active = true;
        canvas.style.cursor = "none";
        borrador.erase();
    }
    document.getElementById("tamano").innerHTML = this.radius;
    redraw();
}

borrador.print = function(context){
    context.beginPath();
    context.arc(this.position[0], this.position[1], this.radius, 0, 2 * Math.PI, false);
    context.fillStyle = this.fillStyle;
    context.fill();

    // context.arc(this.position2[0], this.position2[1], this.radius, 0, 2 * Math.PI, false);
    // context.fillStyle = this.fillStyle;
    // context.fill();

    // context.arc(this.intersectToRections[0], this.intersectToRections[1], 3, 0, 2 * Math.PI, false);
    // context.fillStyle = "blue";
    // context.fill();

    // context.arc(this.intersectToRections[2], this.intersectToRections[3], 3, 0, 2 * Math.PI, false);
    // context.fillStyle = "red";
    // context.fill();

    context.lineWidth = 1;
    context.strokeStyle = this.strokeStyle;
    context.moveTo(this.position[0]-(this.radius/3),this.position[1]);
    context.lineTo(this.position[0]+(this.radius/3),this.position[1]);
    context.moveTo(this.position[0],this.position[1]-(this.radius/3));
    context.lineTo(this.position[0],this.position[1]+(this.radius/3));
    context.stroke();
    context.closePath();
}


