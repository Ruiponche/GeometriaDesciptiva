$(document).keypress(function(e) { 
  redraw();     //shortcuts
    if(e.which == 49) {
        newArc();
       $('#9h').fadeToggle("fast");
       $('#2h').fadeToggle("fast");
       $('#2b').fadeToggle("fast");
       $('#9b').fadeToggle("fast");
    }
    if(e.which == 50) {
        reglaT.activateDeactivate();
        redraw();
        $('#reglaT_girar').fadeToggle();
    }
    if(e.which == 51) {
      escuadra.activateDeactivate()
      $('#escuadraah').fadeToggle();
      $('#escuadrah').fadeToggle();
    }
    if(e.which == 52) {
        cartabon.activateDeactivate();
        $('#cartabonah').fadeToggle();
        $('#cartabonh').fadeToggle();
        $('#cartabonflip').fadeToggle();
    }
    if(e.which == 53) {
        newLine();
       $('#9hl').fadeToggle("fast");
       $('#2hl').fadeToggle("fast");
       $('#2bl').fadeToggle("fast");
       $('#9bl').fadeToggle("fast");
    }
});

   $('#9h').toggle();  //ocultar imagenes al inicio
   $('#2h').toggle();
   $('#2b').toggle();
   $('#9b').toggle();

   $('#9hl').toggle();
   $('#2hl').toggle();
   $('#2bl').toggle();
   $('#9bl').toggle();

   $('#reglaT_girar').toggle();
   
   $('#escuadraah').toggle();
   $('#escuadrah').toggle();
   $('#escuadraunchain').toggle();

  $('#cartabonah').toggle();
  $('#cartabonh').toggle();
  $('#cartabonflip').toggle();
  $('#cartabonunchain').toggle();

  $('#mas').toggle();
  $('#menos').toggle();
  $('#tamano').toggle();
  $('#eliminar').toggle();

  $('#mas_e').toggle();
  $('#menos_e').toggle();
  $('#100_e').toggle();
  $('#tamano_e').toggle();
  $('#mas_t').toggle();
  $('#menos_t').toggle();
  $('#tamano_t').toggle();

$('#compas').click(function() {
  redraw();     //al clickear las herramientas principales
   $('#9h').fadeToggle("fast");
   $('#2h').fadeToggle("fast");
   $('#2b').fadeToggle("fast");
   $('#9b').fadeToggle("fast");
});

$('#reglaT').click(function() {
  redraw();
  $('#reglaT_girar').fadeToggle();
});

$('#escuadra').click(function() {
  redraw();
  escuadra.activateDeactivate()
  $('#escuadraah').fadeToggle();
  $('#escuadrah').fadeToggle();
});

$('#cartabon').click(function() {
  redraw();
  $('#cartabonah').fadeToggle();
  $('#cartabonh').fadeToggle();
  $('#cartabonflip').fadeToggle();
});

$('#lapiz').click(function() {
  redraw();
   $('#9hl').fadeToggle("fast");
   $('#2hl').fadeToggle("fast");
   $('#2bl').fadeToggle("fast");
   $('#9bl').fadeToggle("fast");
});

$('#borrador').click(function() {     //al clickear las herramientas principales
  redraw();
   $('#mas').fadeToggle("fast");
   $('#menos').fadeToggle("fast");
   $('#tamano').fadeToggle("fast");
   $('#eliminar').fadeToggle("fast");
   borrador.activateDeactivate();
});

$('#eliminar').click(function() {
  redraw();
  borrador.changeMode();
});

$('#escalimetro').click(function() {     //al clickear las herramientas principales
   $('#mas_e').fadeToggle("fast");
   $('#menos_e').fadeToggle("fast");
   $('#100_e').fadeToggle("fast");
   $('#tamano_e').fadeToggle("fast");
   $('#mas_t').fadeToggle("fast");
   $('#menos_t').fadeToggle("fast");
   $('#tamano_t').fadeToggle("fast");
});

$('#limpiar').click(function() {     //al clickear las herramientas principales
   for(i = 0 ; i< arcos.length ; i++){
          arcos.length = 0;
        }

    for(i = 0 ; i< rectas.length ; i++){
      rectas.length = 0;
    }

    for(i = 0 ; i< puntos.length ; i++){
      puntos.length = 0;
    }
  redraw();
});

var interval;
var interval_e;
document.getElementById("mas").addEventListener('mousedown',function(e) {
  redraw();
    interval = setInterval(function() {
        borrador.increaseSize();
    },25); // 500ms between each frame
    redraw();
});
document.getElementById("mas").addEventListener('mouseup',function(e) {
    clearInterval(interval);
    redraw();
});
// Thank you, Timo002, for your contribution!
// This code will stop the interval if you move your mouse away from the button while still holding it.
document.getElementById("mas").addEventListener('mouseout',function(e) {
    clearInterval(interval);
    redraw();
});

document.getElementById("menos").addEventListener('mousedown',function(e) {
  redraw();
    interval = setInterval(function() {
        borrador.decreaseSize();
    },10); // 500ms between each frame
    redraw();
});
document.getElementById("menos").addEventListener('mouseup',function(e) {
    clearInterval(interval);
    redraw();
});
// Thank you, Timo002, for your contribution!
// This code will stop the interval if you move your mouse away from the button while still holding it.
document.getElementById("menos").addEventListener('mouseout',function(e) {
    clearInterval(interval);
    redraw();
});


document.getElementById("mas_e").addEventListener('mousedown',function(e) {
    interval_e = setInterval(function() {
        escalimetro.increaseScale();
    },100); // 500ms between each frame
    redraw();
});
document.getElementById("mas_e").addEventListener('mouseup',function(e) {
    clearInterval(interval_e);
    redraw();
});
// Thank you, Timo002, for your contribution!
// This code will stop the interval if you move your mouse away from the button while still holding it.
document.getElementById("mas_e").addEventListener('mouseout',function(e) {
    clearInterval(interval_e);
    redraw();
});

document.getElementById("menos_e").addEventListener('mousedown',function(e) {
    interval_e = setInterval(function() {
        escalimetro.decreaseScale();
    },100); // 500ms between each frame
    redraw();
});
document.getElementById("menos_e").addEventListener('mouseup',function(e) {
    clearInterval(interval_e);
    redraw();
});
// Thank you, Timo002, for your contribution!
// This code will stop the interval if you move your mouse away from the button while still holding it.
document.getElementById("menos_e").addEventListener('mouseout',function(e) {
    clearInterval(interval_e);
    redraw();
});


document.getElementById("mas_t").addEventListener('mousedown',function(e) {
  redraw();
    interval_e = setInterval(function() {
        escalimetro.increaseSize();
    },100); // 500ms between each frame
    redraw();
});
document.getElementById("mas_t").addEventListener('mouseup',function(e) {
    clearInterval(interval_e);
    redraw();
});
// Thank you, Timo002, for your contribution!
// This code will stop the interval if you move your mouse away from the button while still holding it.
document.getElementById("mas_t").addEventListener('mouseout',function(e) {
    clearInterval(interval_e);
    redraw();
});

document.getElementById("menos_t").addEventListener('mousedown',function(e) {
  redraw();
    interval_e = setInterval(function() {
        escalimetro.decreaseSize();
    },100); // 500ms between each frame
    redraw();
});
document.getElementById("menos_t").addEventListener('mouseup',function(e) {
    clearInterval(interval_e);
    redraw();
});
// Thank you, Timo002, for your contribution!
// This code will stop the interval if you move your mouse away from the button while still holding it.
document.getElementById("menos_t").addEventListener('mouseout',function(e) {
    clearInterval(interval_e);
    redraw();
});

function dlCanvas() {
  var activeTools = [0,0,0];   
  if(reglaT.getActive()){
    activeTools[0] = 1;
    reglaT.activateDeactivate();
  }
  if(cartabon.getActive()){
    activeTools[1] = 1;
    cartabon.activateDeactivate();
  }
  if(escuadra.getActive()){
    activeTools[2] = 1;
    escuadra.activateDeactivate();
  }
  var dt = canvas.toDataURL('image/png');
  dt = dt.replace(/^data:image\/[^;]*/, 'data:application/octet-stream');
  dt = dt.replace(/^data:application\/octet-stream/, 'data:application/octet-stream;headers=Content-Disposition%3A%20attachment%3B%20filename=Lamina.png');

  if(activeTools[0]==1){
    reglaT.activateDeactivate();
  }
  if(activeTools[1]==1){
    cartabon.activateDeactivate();
  }
  if(activeTools[2]==1){
    escuadra.activateDeactivate();
  }
  this.href = dt;
};
document.getElementById("dl").addEventListener('click', dlCanvas, false);
