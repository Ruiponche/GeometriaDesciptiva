var enunciado = { 
    active: false,
    number: 2,
};

var canvas2 = document.getElementById('myCanvas2');
var context2 = canvas2.getContext('2d');

enunciado.setNumber =function(n){
  this.number = n;
}

function wrapText(text, x, y, maxWidth, lineHeight) {
var words = text.split(' ');
var line = '';
console.log("asdasd");
for(var n = 0; n < words.length; n++) {
  var testLine = line + words[n] + ' ';
  var metrics = context2.measureText(testLine);
  var testWidth = metrics.width;
  if (testWidth > maxWidth && n > 0) {
    context2.fillText(line, x, y);
    line = words[n] + ' ';
    y += lineHeight;
  }
  else {
    line = testLine;
  }
}
context2.fillText(line, x, y);
return y;
}

function printNumber(){
  context2.fillStyle = "#000000";
context2.font="12px verdana";
var maxWidth = context2.canvas.width -10;
var lineHeight = 25;
var x = 20;
var y = 20;
var text = " ";



    context2.strokeStyle = "black";
    var n = enunciado.number;
    console.log(n);
switch(enunciado.number){
  case 1:
    text ='Trazar la perpendicular que pasa por un punto medio de un segmento de recta AB. Con abertura mayor que la mitad de AB, haga centro con el compas en los extremos A y B para trazar los arcos que determinan los puntos C y D. Uniendo C con D se obtiene la perpendicular';
    var yMax = wrapText(text, x, y, maxWidth, lineHeight);
    context2.beginPath();
    context2.moveTo(80,yMax+ 200);
    context2.lineTo(280,yMax+200);
    context2.stroke();
    context2.closePath();

    context2.beginPath();
    context2.arc(80,yMax+ 200, 200, 0.9, 1.2, 0);
    context2.stroke();
    context2.closePath();

    context2.beginPath();
    context2.arc(80,yMax+ 200, 200, 4.9, 5.3, 0);
    context2.stroke();
    context2.closePath();

    context2.beginPath();
    context2.arc(280,yMax+ 200, 200, 2, 2.3, 0);
    context2.stroke();
    context2.closePath();

    context2.beginPath();
    context2.arc(280,yMax+ 200, 200, 4, 4.3, 0);
    context2.stroke();
    context2.closePath();
  break;
  case 2:
    text ='Trazar una perpendicular en un punto cualquiera de una recta. Siendo C el punto en el segmento de recta AB, se lleva la distancia CB sobre el segmento CA, obteniendose el punto D. Con una abertura mayor que CD, se hace centro en D y B para trazar arcos cuyo corte determine el punto E. La recta CE es perpendicular.';
    var yMax = wrapText(text, x, y, maxWidth, lineHeight);
    context2.beginPath();
    context2.moveTo(90,yMax+ 200);
    context2.lineTo(300,yMax+200);
    context2.stroke();
    context2.closePath();

    context2.beginPath();
    context2.arc(120,yMax+ 200, 120, 4.9, 5.3, 0);
    context2.stroke();
    context2.closePath();

    context2.beginPath();
    context2.arc(200,yMax+ 200, 120, 4.2, 4.6, 0);
    context2.stroke();
    context2.closePath();

    context2.beginPath();
    context2.moveTo(160,yMax+ 200-160);
    context2.lineTo(160,yMax+ 200);
    context2.stroke();
    context2.closePath();

    context2.setLineDash([5]);
    context2.beginPath();
    context2.arc(160,yMax+ 200, 70, 3.14, 0, 0);
    context2.stroke();
    context2.closePath();

  break;
  case 3:
text ='Levantar una perpendicular en el extremo de un segmento de recta. Se señala el punto arbitrario C, por encima del segmento AB. Haciendo centro en ese punto, con radio CB se determina el arco en el que se obtiene el punto D en AB. Se traza una recta que pase por el punto C y llegue al punto E en el otro extremo del arco. La recta trazada desde B a E es perpendicular al segmento AB.';
    var yMax = wrapText(text, x, y, maxWidth, lineHeight);
    context2.beginPath();
    context2.moveTo(80,yMax+ 200);
    context2.lineTo(300,yMax+200);
    context2.stroke();
    context2.closePath();

    context2.beginPath();
    context2.moveTo(160,yMax+ 200-160);
    context2.lineTo(160,yMax+ 200);
    context2.stroke();
    context2.closePath();
  break;
  case 4:
  break;
  case 5:
  break;
  case 6:
  break;
  case 7:
  break;
  case 8:
  break;
  case 9:
  break;
  case 10:
  break;
}

}

enunciado.print = function(){

context2.canvas.width  = window.innerWidth*0.3+10;
context2.canvas.height = window.innerHeight-9;
h=parseInt(canvas2.getAttribute("height"));
w=parseInt(canvas2.getAttribute("width"));
context2.fillStyle = "#eeeeee";
context2.fillRect(0,0,w,h);


printNumber();
}