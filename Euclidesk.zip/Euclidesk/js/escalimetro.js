var escalimetro = {
	translation: [250,10] ,
    startPoint: [0,0],
    endPoint: [0,0],
    rotation: 0,
    size:  5,
    scale:  100,
    nScale:1,
    active: false,
}

$('#escalimetro').click(function() {
    if(!escalimetro.active){
        escalimetro.active = true;
        escalimetro.setAttributes();
    }
    else{
        escalimetro.active = false;
        if(rotador.getAnchor()=="escalimetro"){
            rotador.setActive(false);
        }
     }
     redraw();
});

escalimetro.getRotation = function(){
    return this.rotation;
}
escalimetro.getTranslation = function(){
    return [this.translation[0], this.translation[1]];
}

escalimetro.setTranslation = function(x,y){
    this.translation = [x,y];
}

escalimetro.setRotation = function(r){
        this.rotation = r;
}

escalimetro.clicked = function(x,y){  
    var test = point.translate(x,y,-this.translation[0],-this.translation[1]);
    test = point.rotate(-this.rotation, test[0], test[1],0,0);

    if(test[0]> 0 && test[0]< this.size*40)
        if(test[1]> 0 && test[1]< 18)
            return true;
    if(test[0]< 0 && test[0]> -this.size*40)
        if(test[1]> 0 && test[1]< 18)
            return true;

    return false;
}

escalimetro.calculateDeltaTrans= function(x,y){
    var test = [x-this.translation[0],y-this.translation[1]];
    return test;
}

escalimetro.chooseScale = function(){
    switch(this.nScale){
        case 1:
            this.scale = 20;
            break;
        case 2:
            this.scale = 25;
            break; 
        case 3:
            this.scale = 50;
            break;
        case 4:
            this.scale = 75;
            break;
        case 5:
            this.scale = 100;
            break;
        case 6:
            this.scale = 125;
            break;           
    }
}

escalimetro.increaseScale = function(){
    if(this.nScale<6)
        this.nScale = this.nScale + 1;
    escalimetro.chooseScale();
    document.getElementById("tamano_e").innerHTML = this.scale;
    redraw();
}

escalimetro.decreaseScale = function(){
    if(this.nScale>1)
        this.nScale = this.nScale - 1;
    escalimetro.chooseScale();
    document.getElementById("tamano_e").innerHTML = this.scale;   
    redraw(); 
}

escalimetro.increaseSize = function(){
    if(this.size<30)
        this.size = this.size + 1;
    document.getElementById("tamano_t").innerHTML = this.size*2;
    redraw();
}

escalimetro.decreaseSize = function(){
    if(this.size>1)
        this.size = this.size - 1;
    document.getElementById("tamano_t").innerHTML = this.size*2;   
    redraw(); 
}


escalimetro.setAttributes = function(){
    var deltaTrans;
	var i = 0;
    $('#myCanvas').mousedown(function(e) {
        if(i==0 && !activeTool && escalimetro.clicked(e.pageX-60,e.pageY)){
            deltaTrans = escalimetro.calculateDeltaTrans(e.pageX-60,e.pageY);
            i=1;
        }
        if(rotador.clicked(e.pageX-60, e.pageY) && rotador.getAnchor()=="escalimetro"){
            i=2;
        }
    });

	$('#myCanvas').mousemove(function(e){
        if(i==2 && rotador.getAnchor() == "escalimetro" ){
            escalimetro.setRotation(rotador.rotate(e.pageX-60, e.pageY));
        }
		if (i==1 ){
			escalimetro.setTranslation(e.pageX-60-deltaTrans[0],e.pageY-deltaTrans[1]);
            rotador.setHide(true);
		};

	});

	$('#myCanvas').click(function(e){
		if (i==1 || i==2){
			i=0;
            rotador.setPosition("escalimetro",escalimetro.getRotation(), escalimetro.getTranslation());
		};
	});
}

function generatePoints(){    //extraigo la rotacion y traslacion de la linea y la sitúo horizontal en el origen
	this.rotation = this.findAngle();
	this.translation = this.startPoint;
    this.startPoint = point.translate(x,y,-this.translation[0],-this.translation[1]);
    this.endPoint = point.translate(x,y,-this.translation[0],-this.translation[1]);
    this.endPoint = point.rotate(-this.rotation, this.endPoint[0], this.endPoint[1],0,0);

    var start = 0, end = this.endPoint[0];
    var scaleMin = 4; // 4 pixeles son un centrimetro, este número cambiará dependiendo de la escala

    for(start; start < end ; start+= scaleMin){
    	console.log("lele");
    }

}

function findAngle(A,B,C) {
	var A = this.startPoint,
		B = this.endPoint,
		C = [this.endPoint[0],this.startPoint[1]];
    var AB = Math.sqrt(Math.pow(B.x-A.x,2)+ Math.pow(B.y-A.y,2));    
    var BC = Math.sqrt(Math.pow(B.x-C.x,2)+ Math.pow(B.y-C.y,2)); 
    var AC = Math.sqrt(Math.pow(C.x-A.x,2)+ Math.pow(C.y-A.y,2));
    return Math.acos((BC*BC+AB*AB-AC*AC)/(2*BC*AB));
}

function escala(){
	this.startPoint = [0,0]; 
    this.endPoint = [0,0];
    this.upperPoints = [];
    this.lowerPoints = [];
    this.scale = 100;
    this.rotation = 0;
    this.translation = [0,0];
}

escalimetro.print = function(context){
    context.beginPath();
    context.translate(this.translation[0],this.translation[1]);
    context.rotate(-this.rotation*Math.PI/180);
    context.lineWidth = 0.7;
    context.globalAlpha=1;
    context.strokeStyle = "black";
    
    
    for(i=-(this.size)*40; i<=(this.size)*40; i+=4){
        context.moveTo(i,0);
        if((i+ this.size*40)%400==0){
            context.lineTo(i,18);  
        }else if(i%20==0){
            context.lineTo(i,13);  
        }else{
            context.lineTo(i,8); 
        }
        if((i+ this.size*40)%400==0){
            context.font="14px verdana";
        }else{
            context.font="10px verdana";
        }
        if((i+ this.size*40)%400==0){
            context.fillText(((i+(this.size)*40)/40*escalimetro.scale/100),i-5,29);  
        }
        else if(i%40==0){
            context.fillText(((i+(this.size)*40)/40*escalimetro.scale/100),i-5,22); 
        }
    }

    //console.log("xStart:"+this.startPoint[0]+"yStart:"+this.startPoint[1]);
    //console.log("xEnd:"+this.endPoint[0]+"yEnd:"+this.endPoint[1]);
    context.stroke();
    context.setTransform(1, 0, 0, 1, 0, 0);
    context.closePath();
}