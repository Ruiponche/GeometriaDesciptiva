
      var auxArc = new Arco;
      var arcos = new Array;
      var auxRect = new Recta;
      var rectas = new Array;
      var puntos = new Array;

      function newArc(){
        if(!activeTool){
          auxArc.reset();
          compas.drawArc(arcos, auxArc);
        }
      }

      function newLine(){
        if(!activeTool){
          auxRect.resetRecta();
          lapiz.draw(rectas, auxRect);
        }
      }

$('#myCanvas').mousedown(function(e){
  redraw();
});
$('#myCanvas').mousemove(function(e){
  redraw();
});
$('#myCanvas').mouseup(function(e){
  redraw();
});
      function redraw() {
      var canvas = document.getElementById('myCanvas');
      var context = canvas.getContext('2d');
        if(!enunciado.active){
          context.canvas.width  = window.innerWidth-75;
        }else{
          context.canvas.width  = (window.innerWidth-75)-window.innerWidth*0.3;
          enunciado.print();
        }
        context.canvas.height = window.innerHeight-10;
        context.clearRect(0, 0, canvas.width, canvas.height);

        for(i = 0 ; i< arcos.length ; i++){
          arcos[i].print(context);
        }
        auxArc.print(context);

        for(i = 0 ; i< rectas.length ; i++){
          rectas[i].printRecta(context);
        }
        for(i = 0 ; i< puntos.length ; i++){
          puntos[i].printPunto(context);
        }
        auxRect.printRecta(context);

        if (reglaT.active) {
          reglaT.print(context);
        };

        if(resaltador.active){
          resaltador.print(context);
        };
        
        if(escuadra.active){
          escuadra.print(context);
        };

        if(cartabon.active){
          cartabon.print(context);
        };
        
        if(escalimetro.active){
          escalimetro.print(context);
        }; 

        if(rotador.active && !rotador.hide){
          rotador.print(context);
        };       

        if(borrador.active){
          borrador.print(context);
        }; 

      }
